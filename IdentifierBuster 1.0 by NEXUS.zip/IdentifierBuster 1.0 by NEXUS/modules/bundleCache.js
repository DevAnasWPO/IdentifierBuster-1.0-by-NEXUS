const resolvedBundles = new Map();
const pendingBundles = new Map();
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

function normalizeBundle(playerId, rawResult) {
    if (!rawResult) return null;
    if (rawResult.bundle) return { ...rawResult.bundle, playerId, cachedAt: Date.now() };
    return { playerId, ...rawResult, cachedAt: Date.now() };
}

function isCacheValid(bundle) {
    if (!bundle || !bundle.cachedAt) return false;
    return (Date.now() - bundle.cachedAt) < CACHE_TTL_MS;
}

export const bundleCache = {
    has(playerId) {
        const bundle = resolvedBundles.get(playerId);
        if (!bundle) return false;
        if (!isCacheValid(bundle)) {
            resolvedBundles.delete(playerId);
            return false;
        }
        return true;
    },
    get(playerId) {
        const bundle = resolvedBundles.get(playerId) || null;
        if (bundle && !isCacheValid(bundle)) {
            resolvedBundles.delete(playerId);
            return null;
        }
        return bundle;
    },
    set(playerId, bundle) {
        if (!bundle) return;
        resolvedBundles.set(playerId, { ...bundle, playerId });
        pendingBundles.delete(playerId);
    },
    getOrCreate(playerId, factory) {
        if (resolvedBundles.has(playerId)) {
            return Promise.resolve(resolvedBundles.get(playerId));
        }
        if (pendingBundles.has(playerId)) {
            return pendingBundles.get(playerId);
        }
        const promise = Promise.resolve().then(() => factory()).then(result => {
            const bundle = normalizeBundle(playerId, result);
            if (bundle) {
                resolvedBundles.set(playerId, bundle);
            }
            pendingBundles.delete(playerId);
            return bundle;
        }).catch(error => {
            pendingBundles.delete(playerId);
            throw error;
        });
        pendingBundles.set(playerId, promise);
        return promise;
    },
    clear(playerId) {
        resolvedBundles.delete(playerId);
        pendingBundles.delete(playerId);
    },
    keys() {
        return Array.from(resolvedBundles.keys());
    }
};
