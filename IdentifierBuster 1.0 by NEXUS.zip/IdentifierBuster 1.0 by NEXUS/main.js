// main.js

console.log("EXTENSION: BM Identifier Details Loaded!");

import(chrome.runtime.getURL('./modules/api.js'))
    .then(({ ensureBattleMetricsTokenReady }) => (
        ensureBattleMetricsTokenReady().catch(error => {
            console.warn('BattleMetrics token unavailable at startup', error);
        })
    ))
    .catch(error => console.debug('Token sync module failed to load', error));

import(chrome.runtime.getURL('./modules/progressHud.js'))
    .then(({ mountQueueHud }) => mountQueueHud())
    .catch(error => console.warn('Failed to mount queue HUD', error));

// Use a WeakSet to keep track of elements that have already been processed
// to avoid adding multiple buttons to the same element.
const processedElements = new WeakSet();

async function handleSharedIdentifierElements(elements) {
    // Dynamically import the setup module only when needed
    const { setup } = await import(chrome.runtime.getURL('./modules/setup.js'));
    elements.forEach(element => {
        // If the element hasn't been processed yet, set it up.
        if (!processedElements.has(element)) {
            setup(element);
            processedElements.add(element);
        }
    });
}

// Set up a MutationObserver to watch for dynamic content changes on the page.
// This is necessary because BattleMetrics loads content asynchronously.
const observer = new MutationObserver((mutationsList) => {
    for (const mutation of mutationsList) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
            // Check if any of the added nodes contain our target element
            const targetElements = [];
            mutation.addedNodes.forEach(node => {
                if (node.nodeType === 1) { // Ensure it's an element
                    if (node.matches('.css-98ica9')) {
                        targetElements.push(node);
                    } else {
                        targetElements.push(...node.querySelectorAll('.css-98ica9'));
                    }
                }
            });

            if (targetElements.length > 0) {
                handleSharedIdentifierElements(targetElements);
            }
        }
    }
});

// Start observing the entire body for additions of new elements.
observer.observe(document.body, { childList: true, subtree: true });

// Also run an initial check for any elements that might already be on the page
// when the script loads.
handleSharedIdentifierElements(document.querySelectorAll('.css-98ica9'));